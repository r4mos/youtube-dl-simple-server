https://github.com/r4mos/youtube-dl-simple-server

Instructions
------------
 1. Execute setup.exe and wait for download
 2. Run server: Start button -> Programs -> Startup -> run_youtube-dl-simple-server
 3. Wait 20 seconds and open http://localhost:49149/ Server works!
 4. Close Chrome web browser
 5. Edit Chrome shortcut and add --enable-easy-off-store-extension-install
    Should look like:
    "PATH OF CHROME" --enable-easy-off-store-extension-install
 6. Run that shortcut
 7. Open the extensions page: chrome://extensions
 8. Drag and drop chrome-chromium.crx file in Chrome. Then accepts
 9. Re-edit chrome shortcut and remove --enable-easy-off-store-extension-install

Instrucciones
-------------
 1. Ejecuta setup.exe y espera a que termine la descarga
 2. Ejecuta el servidor: Haz click en el Menú inicio -> Programas -> Inicio -> run_yotube-dl-simple-server
 3. Espera 20 segundos y abre  http://localhost:49149/ El servidor debería funcionar
 4. Cierra el Chrome
 5. Edita el acceso directo al Chrome añadiendo --enable-easy-off-store-extension-install
    Debería quedar así:
    "RUTA DEL CHROME" --enable-easy-off-store-extension-install
 6. Ejecuta ese acceso directo
 7. Ve a la página de extensiones: chrome://extensions
 8. Arrastra y suelta el archivo chrome-chromium.crx en Chrome. Después acepta
 9. Vuelve a editar el acceso directo a Chrome y elimina --enable-easy-off-store-extension-install
